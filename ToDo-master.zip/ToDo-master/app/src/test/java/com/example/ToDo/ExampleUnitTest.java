/*
 * Created by Seyed on 8/3/21, 2:05 PM
 * Copyright (c) 2021 . All rights reserved.
 * Last modified 8/3/21, 1:55 PM
 */

package com.example.ToDo;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
}